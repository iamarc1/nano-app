
# Sudoku Streamlit App

This is a simple Streamlit app that allows users to input a Sudoku puzzle and solve it.

## Features
- Input Sudoku puzzle (use 0 for empty cells)
- Solve the Sudoku puzzle
- Display the original and solved puzzle

## How to Run
1. Clone the repository
2. Install dependencies using `pip install -r requirements.txt`
3. Run the Streamlit app using `streamlit run app.py`
